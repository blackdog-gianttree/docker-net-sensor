# @TEST-EXEC: sh %INPUT

ls /etc | grep -q passwd
