
#include <vector>

class RE_Matcher;

namespace binpac {

std::vector<RE_Matcher*>* uncompiled_re_matchers = 0;

}
